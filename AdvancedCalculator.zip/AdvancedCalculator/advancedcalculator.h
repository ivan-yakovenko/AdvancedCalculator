#pragma once
#include "rpn.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class AdvancedCalculator;
}
QT_END_NAMESPACE

class AdvancedCalculator : public QMainWindow
{
    Q_OBJECT

public:
    AdvancedCalculator(QWidget *parent = nullptr);
    ~AdvancedCalculator();

private:
    Ui::AdvancedCalculator *ui;
    RPN *rpn;
private slots:
    void evaluationbtn_clicked();
};

