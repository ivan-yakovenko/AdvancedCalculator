#include "advancedcalculator.h"
#include "ui_advancedcalculator.h"

using namespace std;

AdvancedCalculator::AdvancedCalculator(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::AdvancedCalculator)
    , rpn(new RPN)
{
    ui->setupUi(this);

    connect(ui->evaluationbtn, &QPushButton::clicked, this, &AdvancedCalculator::evaluationbtn_clicked);
}

AdvancedCalculator::~AdvancedCalculator()
{
    delete ui;
    delete rpn;
}

void AdvancedCalculator::evaluationbtn_clicked() {
    QString expression = ui->expression->text();
    string infixExpression = expression.toStdString();

    string postfixExpression = rpn->infixToPostfix(infixExpression);
    double result = rpn->rpn(postfixExpression);

    ui->output->setText(QString::number(result));
}
